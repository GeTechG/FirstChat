var connection = new WebSocket('ws://25.80.162.89:10000');
connection.onopen = function () {
    connection.send("Привет");
}

connection.onmessage = function(event) {
  alert(event.data);
};